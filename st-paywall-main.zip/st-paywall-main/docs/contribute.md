# Contribute

If you have feedback about this package, please reach out to me on [twitter](https://twitter.com/tylerjrichards) 
or file an issue in [this repo](https://github.com/tylerjrichards/st-paywall/issues).

If you want to contribute with the implementation, feel free to send a Pull Request!