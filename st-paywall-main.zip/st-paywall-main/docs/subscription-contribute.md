# Authentication

## Adding a new subscription

To add a new subscription method:
* Fork the repo and create a new branch
* Code the implementation, making sure to expose the same interface to current versions.
* Do a pull request