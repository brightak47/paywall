from .aggregate_auth import add_auth  # noqa
